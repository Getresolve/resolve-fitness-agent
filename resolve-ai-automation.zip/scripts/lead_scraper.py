from nxtscape import Scraper

def get_leads(area, count):
    s = Scraper()
    leads = s.search_local_business(area=area, category="gym", limit=count)
    return leads
