from fire_enrich import FireEnrich

def enrich(leads):
    fe = FireEnrich()
    return [fe.enrich(lead) for lead in leads]
