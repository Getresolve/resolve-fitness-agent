from composio import Compositor

def send(messages):
    comp = Compositor()
    for msg in messages:
        comp.send_via_gmail(msg)
