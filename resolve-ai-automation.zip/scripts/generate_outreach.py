from quocLM import Chatbot
from composio import Compositor

def write_email(leads, language):
    bot = Chatbot()
    comp = Compositor()
    messages = []
    for lead in leads:
        prompt = f"Write bilingual outreach to {lead['name']} in Japanese + English"
        text = bot.chat(prompt)
        email = comp.compose_email(to=lead['email'], body=text)
        messages.append(email)
    return messages
