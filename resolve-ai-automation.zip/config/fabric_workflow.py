from scripts.lead_scraper import get_leads
from scripts.enrich_leads import enrich
from scripts.generate_outreach import write_email
from scripts.send_email import send

def run():
    leads = get_leads(area="Kanagawa", count=20)
    enriched = enrich(leads)
    outreach = write_email(enriched, language="ja,en")
    send(outreach)

if __name__ == "__main__":
    run()
