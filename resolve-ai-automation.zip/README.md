# Resolve AI Automation

Automated lead gen, enrichment, bilingual outreach, and email sending — all for free using open source tools. Designed for Resolve Fitness in Kanagawa, easily adaptable to other businesses.

## Features
- Scrapes leads from local business directories (via Nxtscape)
- Enriches with email, contact info (via Fire-Enrich)
- Generates bilingual email content (via quocLM)
- Sends automated outreach (via Composio)
- Weekly GitHub Actions automation

## How to Use
1. Clone this repo into GitHub
2. Install dependencies with `pip install -r requirements.txt`
3. Add your credentials as GitHub secrets or environment variables:
   - `GMAIL_USERNAME`
   - `GMAIL_APP_PASSWORD`
   - `NOTION_TOKEN`
   - `NOTION_DATABASE_ID`
4. Push to GitHub
5. Set up Render.com as a scheduled cron job (see documentation)

## Outreach Template Examples

### 🧠 Template 1: Corporate Wellness (JP/EN)

**JP:**
はじめまして。Resolve Fitness and Training Centerのモーリス・シェルトンと申します。社員の健康とウェルビーイングに貢献できるフィットネスプログラムをご紹介したくご連絡しました。

まずは15分ほどお話できるお時間はありますか？

**EN:**
Hello, this is Maurice from Resolve Fitness. I’d love to introduce a bilingual wellness program that enhances employee well-being and productivity.

Would you be open to a 15-minute call?

### 🤝 Template 2: Local Gym Collaboration

**JP:**
突然のご連絡失礼します。Resolve Fitnessのモーリスと申します。貴施設とコラボして外国人や英語を学ぶ方向けのイベントを共催できればと思い、ご連絡しました。

**EN:**
Hi there, this is Maurice from Resolve Fitness. I’d love to explore a potential collaboration with your studio to host bilingual or international-friendly classes.

---

Let’s build better leads, better reach, and better Resolve.
