from config.fabric_workflow import run

def test_pipeline():
    try:
        run()
        print("Pipeline executed successfully.")
    except Exception as e:
        print(f"Pipeline failed: {e}")
